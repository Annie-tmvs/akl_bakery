@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="card-body">
            <h1>Bakery</h1>
        </div>
    </div>
@endsection