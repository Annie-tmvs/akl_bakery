

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h1>Bakery</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AKL-Bakery\resources\views/admin/index.blade.php ENDPATH**/ ?>